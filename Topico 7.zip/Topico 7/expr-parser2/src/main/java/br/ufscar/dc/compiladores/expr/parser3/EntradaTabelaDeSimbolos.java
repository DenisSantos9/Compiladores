package br.ufscar.dc.compiladores.expr.parser3;

public class EntradaTabelaDeSimbolos {
    public String nome;
    public double valor;
}